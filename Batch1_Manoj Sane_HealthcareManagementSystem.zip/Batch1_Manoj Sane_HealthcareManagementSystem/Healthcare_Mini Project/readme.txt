Healthcare Appointment & Patient Management System

Overview :
The Healthcare System is a modern, frontend-based web application designed to efficiently manage patients, doctors, and appointments in a clinic environment.
It replaces manual record-keeping with a structured and user-friendly digital system.

The application is built entirely using HTML, CSS, Bootstrap, JavaScript, and jQuery, with Local Storage used for data persistence.
No backend server is required, making it lightweight and easy to deploy.


1. Doctor Management :
   => Add new doctors with name, specialization, and available time slots
   => Edit doctor details using pre-filled modal forms
   => Delete doctor records with confirmation dialogs
   => Specialization dropdown populated dynamically from JavaScript constants
   => Ensures appointments are booked only within available time slots


2. Patient Management :
   => Add new patients with complete details:

   * Auto-generated Patient ID (visible in UI)
   * Name, Age, Gender
   * Phone Number, Email
   * Medical Notes

=> Edit patient details with modal form
=> Delete patients with confirmation
=> Search patients by name or phone number
=> Strong input validation:

* Age must be valid
* Phone must be 10 digits
* Email validated using regex


3. Appointment Management :
   => Book appointments using dynamic dropdowns (Patient & Doctor)
   => Time slots generated automatically based on doctor's availability
   => Prevent duplicate bookings (same doctor, date, and time)
   => Appointment status management:

   * Booked
   * Completed
   * Cancelled

=> Confirmation dialogs for status changes
=> Filter appointments by:

* Date
* Status

=> Status displayed using Bootstrap badges


4. User Interface :
   => Fully responsive layout using Bootstrap 5
   => Clean navigation bar across all pages
   => Dashboard with summary cards (Patients, Doctors, Appointments)
   => Modal-based forms for all CRUD operations
   => Styled tables with hover effects
   => Bootstrap alert system for:

   * Success messages
   * Error messages
   * Warnings

=> Improved UI/UX with:

* Shadows, spacing, and modern design
* Consistent layout across all modules


5. Technologies Used :
   -> HTML5 – Structure
   -> CSS3 – Styling and layout enhancements
   -> Bootstrap 5 – Responsive UI components
   -> JavaScript (ES6) – Application logic
   -> jQuery – DOM manipulation and event handling
   -> Local Storage – Data persistence (client-side)


6. Folder Structure :
   healthcare-frontend/
   │
   ├─ index.html                # Dashboard page
   ├─ patients.html             # Patient management
   ├─ doctors.html              # Doctor management
   ├─ appointments.html         # Appointment management
   │
   ├─ css/
   │   └─ styles.css            # Global styles
   │
   ├─ js/
   │   ├─ data.js               # LocalStorage handling & ID generation
   │   ├─ common.js             # Utility functions (alerts, validation, helpers)
   │   ├─ patients.js           # Patient CRUD logic
   │   ├─ doctors.js            # Doctor CRUD logic
   │   ├─ appointments.js       # Appointment logic & scheduling
   │
   └─ readme.txt                # Project documentation


7. Usage :

• Open the application

* Open index.html in any modern web browser

• Navigate through modules

* Use the dashboard or navbar to access Patients, Doctors, and Appointments

• Add Doctors

* Go to Doctors page
* Enter doctor name, specialization, and available time slots
* Save the details

• Add Patients

* Go to Patients page
* Enter patient details (name, age, gender, phone, email, notes)
* Save the record

• Book Appointments

* Go to Appointments page
* Select patient and doctor from dropdowns
* Choose date and available time slot
* Click “Book Appointment”

• Manage Appointments

* Mark appointment as Completed
* Cancel appointment if required
* Use filters to view appointments by date or status

• Data Persistence

* All data is automatically saved in browser Local Storage
* Data remains even after page refresh

8. Key Functionalities :

• Patient Management

* Add, edit, delete patient records
* Search patients by name or phone
* Strong validation for input fields

• Doctor Management

* Add, edit, delete doctors
* Specialization dropdown from predefined list
* Define available time slots

• Appointment Management

* Book appointments dynamically
* Prevent duplicate bookings
* Update status (Booked, Completed, Cancelled)
* Filter by date and status

• Data Handling

* Local Storage used for persistence
* Auto-generated unique IDs

• User Interface

* Responsive design using Bootstrap
* Modal-based forms for CRUD operations
* Status badges and alerts for feedback
* Clean and user-friendly layout

• Validation & Alerts

* Regex-based email validation
* Phone and age validation
* Bootstrap alerts instead of default popups

• Additional Features

* Confirmation dialogs for delete and status updates
* Dynamic dropdown population
* Time slot generation based on doctor availability

