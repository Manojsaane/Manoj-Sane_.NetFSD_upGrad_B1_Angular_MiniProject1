// Show Bootstrap alert
function showAlert(message, type = "success") {
    $("#alertBox").html(`
        <div class="alert alert-${type} alert-dismissible fade show">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);
}

// Email validation
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Get patient name from ID
function getPatientName(id) {
    let p = patients.find(x => x.id === id);
    return p ? p.name : "";
}

// Get doctor name from ID
function getDoctorName(id) {
    let d = doctors.find(x => x.id === id);
    return d ? d.name : "";
}