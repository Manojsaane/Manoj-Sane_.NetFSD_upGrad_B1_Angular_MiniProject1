const specializations = [
    "Cardiologist",
    "Dentist",
    "Pediatrician",
    "Orthopedic",
    "Dermatologist",
    "Neurologist",
    "Psychiatrist",
    "General Physician"
]

let editDoctorId = null;

$(document).ready(function () {
    loadSpecializations();
    renderDoctors();

    $("#saveDoctor").click(saveDoctor);
});

function loadSpecializations() {
    let dropdown = $("#specialization");
    dropdown.empty();
    dropdown.append(`<option value="">Select Specialization</option>`);

    specializations.forEach(s => {
        dropdown.append(`<option value="${s}">${s}</option>`);
    });
}

function renderDoctors() {
    let table = $("#doctorTable");
    table.empty();

    doctors.forEach(d => {
        table.append(`
        <tr>
            <td>${d.id}</td>
            <td>${d.name}</td>
            <td>${d.specialization}</td>
            <td>${d.slot}</td>
            <td>
                <button class="btn btn-warning btn-sm" onclick="editDoctor('${d.id}')">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deleteDoctor('${d.id}')">Delete</button>
            </td>
        </tr>
        `);
    });
}

function saveDoctor() {
    let name = $("#docName").val().trim();
    let specialization = $("#specialization").val();
    let slot = $("#slot").val();

    if (!name) return showAlert("Name required", "danger");
    if (!specialization) return showAlert("Select specialization", "danger");
    if (!slot) return showAlert("Select slot", "danger");

    if (editDoctorId === null) {
        doctors.push({
            id: generateSequentialId("D"),
            name, specialization, slot
        });
    } else {
        let d = doctors.find(x => x.id === editDoctorId);
        Object.assign(d, { name, specialization, slot });
        editDoctorId = null;
    }

    saveData();
    renderDoctors();

    bootstrap.Modal.getInstance(document.getElementById("doctorModal")).hide();
    showAlert("Doctor saved successfully");
}

function editDoctor(id) {
    let d = doctors.find(x => x.id === id);

    $("#docName").val(d.name);
    $("#specialization").val(d.specialization);
    $("#slot").val(d.slot);

    editDoctorId = id;
    new bootstrap.Modal(document.getElementById("doctorModal")).show();
}

function deleteDoctor(id) {
    if (!confirm("Delete this doctor?")) return;

    doctors = doctors.filter(d => d.id !== id);
    saveData();
    renderDoctors();

    showAlert("Doctor deleted", "warning");
}