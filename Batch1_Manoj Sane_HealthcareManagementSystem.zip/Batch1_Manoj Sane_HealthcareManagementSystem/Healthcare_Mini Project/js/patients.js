let editPatientId = null;

$(document).ready(function () {
    renderPatients();

    $("#savePatient").click(savePatient);
    $("#searchPatient").keyup(searchPatient);

    $("#patientModal").on('show.bs.modal', function () {
        if (editPatientId === null) {
            $("#patientId").val("Auto Generated");
        }
    });
});

// Render table
function renderPatients() {
    let table = $("#patientTable");
    table.empty();

    patients.forEach(p => {
        table.append(`
        <tr>
            <td>${p.id}</td>
            <td>${p.name}</td>
            <td>${p.age}</td>
            <td>${p.gender}</td>
            <td>${p.phone}</td>
            <td>${p.email}</td>
            <td>${p.notes}</td>
            <td>
                <button class="btn btn-warning btn-sm" onclick="editPatient('${p.id}')">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deletePatient('${p.id}')">Delete</button>
            </td>
        </tr>
        `);
    });
}

// Save patient
function savePatient() {
    let name = $("#name").val();
    let age = parseInt($("#age").val());
    let gender = $("#gender").val();
    let phone = $("#phone").val();
    let email = $("#email").val();
    let notes = $("#notes").val();

    // Validation
    if (!name.trim()) return showAlert("Name required", "danger");
    if (age <= 0 || isNaN(age)) return showAlert("Invalid age", "danger");
    if (!gender) return showAlert("Select gender", "danger");
    if (!/^[0-9]{10}$/.test(phone)) return showAlert("Invalid phone", "danger");
    if (!isValidEmail(email)) return showAlert("Invalid email", "danger");

    if (editPatientId === null) {
        patients.push({
            id: generateSequentialId("P"),
            name, age, gender, phone, email, notes
        });
    } else {
        let p = patients.find(x => x.id === editPatientId);
        Object.assign(p, { name, age, gender, phone, email, notes });
        editPatientId = null;
    }

    saveData();
    renderPatients();
    clearForm();

    bootstrap.Modal.getInstance(document.getElementById("patientModal")).hide();
    showAlert("Patient saved successfully");
}

// Edit
function editPatient(id) {
    let p = patients.find(x => x.id === id);

    $("#patientId").val(p.id);
    $("#name").val(p.name);
    $("#age").val(p.age);
    $("#gender").val(p.gender);
    $("#phone").val(p.phone);
    $("#email").val(p.email);
    $("#notes").val(p.notes);

    editPatientId = id;
    new bootstrap.Modal(document.getElementById("patientModal")).show();
}

// Delete
function deletePatient(id) {
    if (!confirm("Delete this patient?")) return;

    patients = patients.filter(p => p.id !== id);
    saveData();
    renderPatients();

    showAlert("Patient deleted", "warning");
}

// Search
function searchPatient() {
    let text = $("#searchPatient").val().toLowerCase();

    let filtered = patients.filter(p =>
        p.name.toLowerCase().includes(text) ||
        p.phone.includes(text)
    );

    let table = $("#patientTable");
    table.empty();

    filtered.forEach(p => {
        table.append(`<tr>
            <td>${p.id}</td>
            <td>${p.name}</td>
            <td>${p.age}</td>
            <td>${p.gender}</td>
            <td>${p.phone}</td>
            <td>${p.email}</td>
            <td>${p.notes}</td>
            <td>
                <button class="btn btn-warning btn-sm" onclick="editPatient('${p.id}')">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deletePatient('${p.id}')">Delete</button>
            </td>
        </tr>`);
    });
}

function clearForm() {
    $("#name, #age, #gender, #phone, #email, #notes").val("");
}