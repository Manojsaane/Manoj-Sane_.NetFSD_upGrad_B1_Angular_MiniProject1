$(document).ready(function () {
    loadPatients();
    loadDoctors();
    renderAppointments();
    setMinDate();

    $("#bookAppointment").click(bookAppointment);
    $("#filterDate, #filterStatus").change(filterAppointments);
    $("#doctor").change(generateTimeSlots);
});

// Prevent past date
function setMinDate() {
    let today = new Date().toISOString().split("T")[0];
    $("#date").attr("min", today);
}

// Load dropdowns
function loadPatients() {
    let dropdown = $("#patient");
    dropdown.empty().append(`<option value="">Select Patient</option>`);

    patients.forEach(p => {
        dropdown.append(`<option value="${p.id}">${p.name}</option>`);
    });
}

function loadDoctors() {
    let dropdown = $("#doctor");
    dropdown.empty().append(`<option value="">Select Doctor</option>`);

    doctors.forEach(d => {
        dropdown.append(`<option value="${d.id}">${d.name}</option>`);
    });
}

// Generate slots
function generateTimeSlots() {
    let doctorId = $("#doctor").val();
    let doctor = doctors.find(d => d.id === doctorId);

    let dropdown = $("#time");
    dropdown.empty().append(`<option value="">Select Time Slot</option>`);

    if (!doctor) return;

    let [start, end] = doctor.slot.split("-");
    let current = convertToMinutes(start.trim());
    let endTime = convertToMinutes(end.trim());

    while (current + 30 <= endTime) {
        let next = current + 30;
        dropdown.append(`<option>${formatTime(current)} - ${formatTime(next)}</option>`);
        current = next;
    }
}

function convertToMinutes(time) {
    let [h, m] = time.split(":").map(Number);
    if (h < 9) h += 12;
    return h * 60 + m;
}

function formatTime(min) {
    let h = Math.floor(min / 60);
    let m = min % 60;
    if (h > 12) h -= 12;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

// Book appointment
function bookAppointment() {
    let patient = $("#patient").val();
    let doctor = $("#doctor").val();
    let date = $("#date").val();
    let time = $("#time").val();

    if (!patient || !doctor || !date || !time)
        return showAlert("Fill all fields", "danger");

    let conflict = appointments.some(a =>
        a.doctor === doctor && a.date === date && a.time === time
    );

    if (conflict)
        return showAlert("Slot already booked", "danger");

    appointments.push({
        id: generateSequentialId("A"),
        patient: getPatientName(patient),
        doctor: getDoctorName(doctor),
        date, time,
        status: "Booked"
    });

    saveData();
    renderAppointments();

    bootstrap.Modal.getInstance(document.getElementById("appointmentModal")).hide();
    showAlert("Appointment booked successfully");
}

// Render table
function renderAppointments(list = appointments) {
    let tbody = $("#appointmentTable tbody");
    tbody.empty();

    list.forEach(a => {
        let actions = a.status === "Booked" ? `
            <button class="btn btn-success btn-sm me-1" onclick="completeAppointment('${a.id}')">Complete</button>
            <button class="btn btn-danger btn-sm" onclick="cancelAppointment('${a.id}')">Cancel</button>
        ` : `<span class="text-muted">No Actions</span>`;

        tbody.append(`
        <tr>
            <td>${a.id}</td>
            <td>${a.patient}</td>
            <td>${a.doctor}</td>
            <td>${a.date}</td>
            <td>${a.time}</td>
            <td>${getBadge(a.status)}</td>
            <td>${actions}</td>
        </tr>
        `);
    });
}

function getBadge(status) {
    if (status === "Booked") return `<span class="badge bg-primary">Booked</span>`;
    if (status === "Completed") return `<span class="badge bg-success">Completed</span>`;
    if (status === "Cancelled") return `<span class="badge bg-danger">Cancelled</span>`;
}

// Actions with confirmation
function completeAppointment(id) {
    if (!confirm("Mark as completed?")) return;

    let a = appointments.find(x => x.id === id);
    a.status = "Completed";

    saveData();
    renderAppointments();
    showAlert("Appointment completed", "success");
}

function cancelAppointment(id) {
    if (!confirm("Cancel appointment?")) return;

    let a = appointments.find(x => x.id === id);
    a.status = "Cancelled";

    saveData();
    renderAppointments();
    showAlert("Appointment cancelled", "warning");
}

// Filter
function filterAppointments() {
    let date = $("#filterDate").val();
    let status = $("#filterStatus").val();

    let filtered = appointments.filter(a =>
        (date === "" || a.date === date) &&
        (status === "" || a.status === status)
    );

    renderAppointments(filtered);
}